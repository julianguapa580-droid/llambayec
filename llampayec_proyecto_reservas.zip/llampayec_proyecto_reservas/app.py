# ============================================================
# LLAMPAYEC - Backend de Reservas
# Servidor puro de Python (sin instalar nada extra)
# Requiere: Python 3.8+  ->  ejecutar:  python app.py
# Abrir en el navegador:  http://localhost:8000
# ============================================================
import json
import re
import sqlite3
import hashlib
import secrets
import hmac
from http.cookies import SimpleCookie
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, urlencode
import urllib.request
import urllib.error
from pathlib import Path
from io import BytesIO

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
    from reportlab.pdfgen import canvas
except Exception:  # también captura errores de Pillow en versiones nuevas de Python
    colors = None

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.worksheet.table import Table as ExcelTable, TableStyleInfo
    from openpyxl.utils import get_column_letter
except Exception:  # también captura errores de Pillow en versiones nuevas de Python
    Workbook = None

BASE_DIR = Path(__file__).parent
STATIC_DIR = BASE_DIR / "static"
DB_PATH = BASE_DIR / "llampayec.db"
PUERTO = 8000
SESIONES = {}  # sesiones activas en memoria; se cierran al reiniciar el servidor
USUARIOS_SESION = {}  # token -> usuario, para la auditoría
SESION_ROL = {}  # token -> rol (ADMIN o CAJERO)
CLIENTE_COOKIE = "llampayec_cliente"
CLIENTE_SESIONES = {}  # token -> {id, nombre, correo, expira}
ROLES_VALIDOS = ("ADMIN", "CAJERO")
SESSION_HOURS = 8
USUARIO_INICIAL = "admin"
CLAVE_INICIAL = "Llampa2026!"
EMPRESA_DEFECTO = {
    "ruc": "", "razon_social": "", "direccion": "", "telefono": "",
    "igv_tasa": "18", "ruc_api_url": "", "ruc_api_token": "",
    "dni_api_url": "", "dni_api_token": "",
}
METODOS_CAJA = ["Efectivo", "Tarjeta", "Yape", "Plin", "PayPal"]
METODOS_WEB = ["Tarjeta", "Yape", "Plin", "PayPal"]  # compra en línea del cliente (sin efectivo)

CONTACTO_DEFECTO = {
    "telefono": "+51 999 999 999",
    "email": "reservas@llampayec.pe",
    "direccion": "Terminal Terrestre, Lima",
}


def hash_clave(clave, sal=None):
    sal = sal or secrets.token_hex(16)
    derivada = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), bytes.fromhex(sal), 200000).hex()
    return sal, derivada


def verificar_clave(clave, sal, derivada):
    return hmac.compare_digest(hash_clave(clave, sal)[1], derivada)

# ------------------------------------------------------------
# BASE DE DATOS (SQL - SQLite)
# ------------------------------------------------------------
def conectar():
    # timeout: espera hasta 30 s si otra venta está escribiendo (antes solo 5 s).
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn

def crear_tablas():
    conn = conectar()
    cur = conn.cursor()
    # WAL: lecturas y escrituras pueden ocurrir a la vez (muchos usuarios). Se guarda en el archivo.
    conn.execute("PRAGMA journal_mode=WAL")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT UNIQUE NOT NULL,
            sal TEXT NOT NULL,
            clave_hash TEXT NOT NULL,
            creado TEXT NOT NULL
        )
    """)
    if cur.execute("SELECT COUNT(*) c FROM usuarios").fetchone()["c"] == 0:
        sal, clave_hash = hash_clave(CLAVE_INICIAL)
        cur.execute("INSERT INTO usuarios(usuario, sal, clave_hash, creado) VALUES(?,?,?,?)",
                    (USUARIO_INICIAL, sal, clave_hash, datetime.now().isoformat(timespec="seconds")))
    cur.execute("""
        CREATE TABLE IF NOT EXISTS rutas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            origen TEXT NOT NULL,
            destino TEXT NOT NULL,
            precio REAL NOT NULL,
            horario TEXT NOT NULL,
            duracion TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS reservas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            ruta_id INTEGER NOT NULL,
            asiento INTEGER NOT NULL,
            pasajero TEXT NOT NULL,
            tipo_documento TEXT NOT NULL DEFAULT 'DNI',
            dni TEXT NOT NULL,
            telefono TEXT NOT NULL,
            metodo_pago TEXT NOT NULL,
            total REAL NOT NULL,
            fecha TEXT NOT NULL,
            estado TEXT DEFAULT 'CONFIRMADA',
            FOREIGN KEY (ruta_id) REFERENCES rutas(id)
        )
    """)
    if cur.execute("SELECT COUNT(*) c FROM rutas").fetchone()["c"] == 0:
        rutas = [
            ("Lima", "Chimbote", 60, "8:00 am - 10:30 pm", "7 horas"),
            ("Lima", "Trujillo", 65, "8:00 am - 11:00 pm", "9 horas"),
            ("Lima", "Chiclayo", 80, "9:00 am - 11:30 pm", "11 horas"),
            ("Lima", "Piura", 70, "9:00 am - 12:00 am", "14 horas"),
            ("Lima", "Mancora", 110, "2:00 pm - 12:00 am", "17 horas"),
            ("Lima", "Tumbes", 130, "2:00 pm - 12:30 am", "18 horas"),
            ("Lima", "Aguas Verdes", 140, "3:00 pm - 12:30 am", "19 horas"),
        ]
        cur.executemany(
            "INSERT INTO rutas (origen, destino, precio, horario, duracion) VALUES (?,?,?,?,?)",
            rutas
        )
    if "capacidad" not in [r[1] for r in cur.execute("PRAGMA table_info(rutas)").fetchall()]:
        cur.execute(f"ALTER TABLE rutas ADD COLUMN capacidad INTEGER NOT NULL DEFAULT {CAPACIDAD_DEFECTO}")
    if "pisos" not in [r[1] for r in cur.execute("PRAGMA table_info(rutas)").fetchall()]:
        cur.execute("ALTER TABLE rutas ADD COLUMN pisos INTEGER NOT NULL DEFAULT 1")
    for columna in ("precio_piso1", "precio_piso2"):  # NULL = usa el precio general
        if columna not in [r[1] for r in cur.execute("PRAGMA table_info(rutas)").fetchall()]:
            cur.execute(f"ALTER TABLE rutas ADD COLUMN {columna} REAL")
    # Compatibilidad con versiones anteriores de la base de datos.
    columnas = [r[1] for r in cur.execute("PRAGMA table_info(reservas)").fetchall()]
    if "tipo_documento" not in columnas:
        cur.execute("ALTER TABLE reservas ADD COLUMN tipo_documento TEXT NOT NULL DEFAULT 'DNI'")
    cur.execute("CREATE TABLE IF NOT EXISTS contacto (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")
    for clave, valor in CONTACTO_DEFECTO.items():
        cur.execute("INSERT OR IGNORE INTO contacto (clave, valor) VALUES (?,?)", (clave, valor))
    if "abordado" not in [r[1] for r in cur.execute("PRAGMA table_info(reservas)").fetchall()]:
        cur.execute("ALTER TABLE reservas ADD COLUMN abordado INTEGER NOT NULL DEFAULT 0")
    cur.execute("""CREATE TABLE IF NOT EXISTS auditoria (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     fecha TEXT NOT NULL, usuario TEXT NOT NULL,
                     accion TEXT NOT NULL, detalle TEXT NOT NULL)""")
    existentes = [r[1] for r in cur.execute("PRAGMA table_info(reservas)").fetchall()]
    for nombre, definicion in [("canal", "TEXT NOT NULL DEFAULT 'WEB'"), ("monto_recibido", "REAL"), ("vuelto", "REAL")]:
        if nombre not in existentes:
            cur.execute(f"ALTER TABLE reservas ADD COLUMN {nombre} {definicion}")
    columnas_u = [r[1] for r in cur.execute("PRAGMA table_info(usuarios)").fetchall()]
    for nombre, definicion in [("nombre", "TEXT"), ("correo", "TEXT"),
                               ("rol", "TEXT NOT NULL DEFAULT 'ADMIN'"), ("activo", "INTEGER NOT NULL DEFAULT 1")]:
        if nombre not in columnas_u:
            cur.execute(f"ALTER TABLE usuarios ADD COLUMN {nombre} {definicion}")
    columnas_r = [r[1] for r in cur.execute("PRAGMA table_info(reservas)").fetchall()]
    for nombre, definicion in [("cliente_ruc", "TEXT"), ("cliente_razon", "TEXT"),
                               ("base_imponible", "REAL"), ("igv", "REAL")]:
        if nombre not in columnas_r:
            cur.execute(f"ALTER TABLE reservas ADD COLUMN {nombre} {definicion}")
    cur.execute("CREATE TABLE IF NOT EXISTS empresa (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")
    for clave, valor in EMPRESA_DEFECTO.items():
        cur.execute("INSERT OR IGNORE INTO empresa (clave, valor) VALUES (?,?)", (clave, valor))
    cur.execute("""CREATE TABLE IF NOT EXISTS clientes (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     nombre TEXT NOT NULL, correo TEXT UNIQUE NOT NULL,
                     sal TEXT NOT NULL, clave_hash TEXT NOT NULL,
                     creado TEXT NOT NULL, activo INTEGER NOT NULL DEFAULT 1)""")
    if "cliente_correo" not in [r[1] for r in cur.execute("PRAGMA table_info(reservas)").fetchall()]:
        cur.execute("ALTER TABLE reservas ADD COLUMN cliente_correo TEXT")
    # Evita dobles reservas del mismo asiento para una misma ruta y fecha.
    cur.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_asiento_fecha
                   ON reservas(ruta_id, asiento, fecha)
                   WHERE estado='CONFIRMADA'""")
    conn.commit()
    conn.close()

CAPACIDAD_DEFECTO = 40  # asientos del bus si la ruta no indica otra cosa
FILAS_POR_CROQUIS = 16  # filas de asientos por página del croquis (se parte si el bus es más grande)


def datos_reporte(fecha=None):
    """Devuelve rutas, reservas y asientos para exportaciones."""
    fecha = fecha or datetime.now().strftime("%Y-%m-%d")
    conn = conectar()
    reservas = conn.execute("""
        SELECT r.id, r.codigo, r.ruta_id, r.asiento, r.pasajero, r.tipo_documento,
               r.dni, r.telefono, r.metodo_pago, r.total, r.fecha, r.estado,
               ru.origen, ru.destino, ru.precio, ru.horario, ru.duracion
        FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id
        WHERE r.fecha = ? AND r.estado = 'CONFIRMADA' ORDER BY ru.id, r.asiento
    """, (fecha,)).fetchall()
    rutas = conn.execute("SELECT * FROM rutas ORDER BY id").fetchall()
    conn.close()
    return fecha, [dict(x) for x in reservas], [dict(x) for x in rutas]


def disposicion_rango(lo, hi):
    """Filas de 4 posiciones para los asientos lo..hi (2 + pasillo + 2)."""
    filas, n = [], lo
    while n <= hi:
        fila = []
        for _ in range(4):
            fila.append(n if n <= hi else None)
            n += 1
        filas.append(fila)
    return filas


def disposicion_piso(lo, hi, piso):
    """Con 2 pisos. Piso 1: 2 filas libres arriba (escalera delante del baño, y el baño delante de
    49 y 50) y luego filas de 3 (2 a la izquierda y 1 a la derecha). Piso 2: 2 + pasillo + 2, donde la
    escalera va delante de 15 y 16 (lado derecho): los de la derecha bajan una fila y 13-14 quedan
    detrás de 9-10. Otros casos: 2 + pasillo + 2."""
    if piso == 2:
        bloques = -(-(hi - lo + 1) // 4)
        escalera = bloques > 3

        def par(b, desde):
            ini = lo + 4 * b + desde
            return [n if n <= hi else None for n in (ini, ini + 1)]

        filas = []
        for f in range(bloques + (1 if escalera else 0)):
            izq = par(f, 0) if f < bloques else [None, None]
            if not escalera or f < 3:
                der = par(f, 2) if f < bloques else [None, None]
            elif f == 3:
                der = [None, None]  # fila de la escalera (lado derecho)
            else:
                der = par(f - 1, 2)
            filas.append(izq + der)
        return filas
    if piso == 1:
        filas, n = [[None, None, None, None], [None, None, None, None]], lo
        while n <= hi:
            filas.append([n if n <= hi else None, n + 1 if n + 1 <= hi else None,
                          n + 2 if n + 2 <= hi else None, None])
            n += 3
        return filas
    return disposicion_rango(lo, hi)


def disposicion_asientos(capacidad):
    """Filas de 4 posiciones (2 + pasillo + 2). Cada posición es el número de asiento o None."""
    filas, n = [], 1
    while n <= capacidad:
        fila = []
        for _ in range(4):
            fila.append(n if n <= capacidad else None)
            n += 1
        filas.append(fila)
    return filas


def _ocupados_por_ruta(reservas):
    mapa = {}
    for r in reservas:
        if r["estado"] == "CONFIRMADA":
            mapa.setdefault(r["ruta_id"], {})[int(r["asiento"])] = r
    return mapa


def crear_pdf_reporte(fecha=None):
    if colors is None:
        raise RuntimeError("Falta ReportLab. Ejecuta: pip install reportlab")
    from xml.sax.saxutils import escape as xesc
    from reportlab.platypus import Flowable
    fecha, reservas, rutas = datos_reporte(fecha)
    empresa = leer_empresa()
    azul = colors.HexColor('#173b7a')
    salida = BytesIO()
    doc = SimpleDocTemplate(salida, pagesize=A4, leftMargin=28, rightMargin=28, topMargin=36, bottomMargin=36,
                            title=f"Manifiesto de pasajeros {fecha}", author="LLAMPAYEC")
    estilos = getSampleStyleSheet()
    titulo = ParagraphStyle('TituloLL', parent=estilos['Title'], alignment=TA_CENTER, fontSize=17, leading=21, spaceAfter=4)
    subtitulo = ParagraphStyle('SubLL', parent=estilos['Normal'], alignment=TA_CENTER, fontSize=9, leading=11,
                               textColor=colors.HexColor('#555555'), spaceAfter=10)
    normal = ParagraphStyle('NormLL', parent=estilos['Normal'], fontSize=9, leading=12)
    celda = ParagraphStyle('CeldaLL', parent=normal, fontSize=7.5, leading=9)
    celda_c = ParagraphStyle('CeldaCLL', parent=celda, alignment=TA_CENTER)
    cabecera = ParagraphStyle('CabLL', parent=celda, textColor=colors.white, fontName='Helvetica-Bold', alignment=TA_CENTER)
    seccion = ParagraphStyle('SecLL', parent=estilos['Heading3'], fontSize=11, leading=14, spaceBefore=10, spaceAfter=5, textColor=azul)

    def tabla(filas, anchos, alinear_centro=()):
        datos = []
        for i, fila in enumerate(filas):
            estilo = cabecera if i == 0 else celda
            datos.append([Paragraph(xesc(str(v)), estilo) for v in fila])
        t = Table(datos, colWidths=anchos, repeatRows=1)
        estilo_t = [
            ('BACKGROUND', (0, 0), (-1, 0), azul), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#b7c1d1')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f1f5fa')]),
            ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ]
        t.setStyle(TableStyle(estilo_t))
        return t

    class Croquis(Flowable):
        """Croquis del bus igual que en la caja: butacas con respaldo, 2 + pasillo + 2.
        Con 2 pisos: piso 2 (asientos 1..N) y piso 1 (resto). Escalera y baño punteados."""
        PASO = 28          # alto de cada fila
        BUS_W = 300        # ancho del bus
        COLS = [70, 110, 190, 230]  # centros x: izq-izq, izq-der, pasillo, der-der

        def __init__(self, nombre, bloques, capacidad, ocupados):
            Flowable.__init__(self)
            self.nombre, self.bloques, self.capacidad, self.ocupados = nombre, bloques, capacidad, ocupados
            self.alto = sum(len(b['filas']) * self.PASO + 46 for b in bloques) + 50

        def wrap(self, availW, availH):
            self.ancho = availW
            return availW, self.alto

        def _asiento(self, c, cx, yb, n, ocupado):
            fondo = colors.HexColor('#FF5252') if ocupado else colors.HexColor('#FFE0B2')
            borde = colors.HexColor('#E53935') if ocupado else colors.HexColor('#FFB74D')
            texto = colors.white if ocupado else colors.HexColor('#7A4A00')
            c.setFillColor(fondo); c.setStrokeColor(borde); c.setLineWidth(0.9)
            c.roundRect(cx - 13, yb + 13, 26, 9, 4, stroke=1, fill=1)   # respaldo
            c.roundRect(cx - 15, yb, 30, 16, 5, stroke=1, fill=1)       # asiento
            c.setFillColor(texto); c.setFont('Helvetica-Bold', 7.5)
            c.drawCentredString(cx, yb + 4.5, str(n))

        def _caja(self, c, x0, x1, yb, texto):
            c.setFillColor(colors.white); c.setStrokeColor(colors.HexColor('#999999')); c.setLineWidth(0.8)
            c.setDash(3, 2)
            c.roundRect(x0, yb, x1 - x0, 18, 6, stroke=1, fill=1)
            c.setDash()
            c.setFillColor(colors.HexColor('#555555')); c.setFont('Helvetica-Bold', 7)
            c.drawCentredString((x0 + x1) / 2, yb + 6, texto)

        def draw(self):
            c = self.canv
            ox = (self.ancho - self.BUS_W) / 2
            y = self.alto
            for b in self.bloques:
                alto_b = len(b['filas']) * self.PASO + 12
                c.setFillColor(azul); c.setFont('Helvetica-Bold', 9)
                c.drawCentredString(ox + self.BUS_W / 2, y - 12, b['titulo'])
                sup = y - 20
                c.setFillColor(colors.HexColor('#FAFBFD')); c.setStrokeColor(colors.HexColor('#C9D2E3'))
                c.setLineWidth(1)
                c.roundRect(ox, sup - alto_b, self.BUS_W, alto_b, 14, stroke=1, fill=1)
                for f, fila in enumerate(b['filas']):
                    yb = sup - 28 - f * self.PASO
                    if b.get('piso') == 1 and fila[0] is not None:
                        # pared a la izquierda de cada fila de piso 1 (como en la caja)
                        c.setStrokeColor(colors.HexColor('#BBBBBB')); c.setLineWidth(1)
                        c.line(ox + self.COLS[0] - 24, yb - 2, ox + self.COLS[0] - 24, yb + 18)
                    for n, cx in zip(fila, self.COLS):
                        if n is not None:
                            self._asiento(c, ox + cx, yb, n, n in self.ocupados)
                for fila_esp, a, z, texto in b.get('especiales', []):
                    yb = sup - 28 - fila_esp * self.PASO + 2
                    self._caja(c, ox + self.COLS[a] - 17, ox + self.COLS[z] + 17, yb, texto)
                y = sup - alto_b - 14

            # leyenda
            cap = self.capacidad
            vendidos = len(self.ocupados)
            ly = 12
            c.setFillColor(colors.HexColor('#444444')); c.setFont('Helvetica', 7.5)
            c.drawCentredString(self.ancho / 2, ly + 22,
                                f'Capacidad: {cap} asientos · Vendidos: {vendidos} · Libres: {cap - vendidos}')
            c.setFillColor(colors.HexColor('#FFE0B2')); c.setStrokeColor(colors.HexColor('#FFB74D'))
            c.roundRect(self.ancho / 2 - 110, ly, 10, 10, 2, stroke=1, fill=1)
            c.setFillColor(colors.black); c.setFont('Helvetica', 7); c.drawString(self.ancho / 2 - 96, ly + 2, 'Disponible')
            c.setFillColor(colors.HexColor('#FF5252')); c.setStrokeColor(colors.HexColor('#E53935'))
            c.roundRect(self.ancho / 2 - 25, ly, 10, 10, 2, stroke=1, fill=1)
            c.setFillColor(colors.black); c.drawString(self.ancho / 2 - 11, ly + 2, 'Vendido')

    elementos = []
    elementos.append(Paragraph('MANIFIESTO DE PASAJEROS', titulo))
    elementos.append(Paragraph('LLAMPAYEC — Reporte digital de viaje y control de pasajeros', subtitulo))
    if empresa.get("razon_social") or empresa.get("ruc"):
        elementos.append(Paragraph(f'<b>Empresa:</b> {xesc(empresa.get("razon_social") or "-")} &nbsp;&nbsp; '
                                   f'<b>RUC:</b> {xesc(empresa.get("ruc") or "-")}', normal))
    elementos.append(Paragraph(f'<b>Fecha del viaje:</b> {fecha} &nbsp;&nbsp; '
                               f'<b>Generado:</b> {datetime.now().strftime("%d/%m/%Y %H:%M")}', normal))

    ocupados_ruta = _ocupados_por_ruta(reservas)
    elementos.append(Paragraph('Resumen por ruta', seccion))
    resumen = [['Ruta', 'Horario', 'Capacidad', 'Pasajeros', 'Libres', 'Recaudación']]
    total_pax, total_monto = 0, 0.0
    for ru in rutas:
        pax = ocupados_ruta.get(ru['id'], {})
        recaudado = sum(float(x['total']) for x in pax.values())
        total_pax += len(pax); total_monto += recaudado
        resumen.append([f"{ru['origen']} → {ru['destino']}", ru['horario'], str(ru['capacidad']),
                        str(len(pax)), str(int(ru['capacidad']) - len(pax)), f"S/ {recaudado:.2f}"])
    resumen.append(['TOTAL', '', '', str(total_pax), '', f"S/ {total_monto:.2f}"])
    elementos.append(tabla(resumen, [150, 130, 62, 62, 52, 83]))

    if not reservas:
        elementos.append(Spacer(1, 12))
        elementos.append(Paragraph('No existen pasajeros confirmados para esta fecha.', normal))
    else:
        for ru in rutas:
            pax = ocupados_ruta.get(ru['id'])
            if not pax:
                continue
            elementos.append(Paragraph(f"Ruta: {xesc(ru['origen'])} → {xesc(ru['destino'])} &nbsp;&nbsp; "
                                       f"Horario: {xesc(ru['horario'])} &nbsp;&nbsp; Duración: {xesc(ru['duracion'])}", seccion))
            filas = [['N°', 'Código', 'Pasajero', 'Documento', 'Teléfono', 'Asiento', 'Pago', 'Tarifa', 'Estado']]
            for i, asiento in enumerate(sorted(pax), 1):
                r = pax[asiento]
                filas.append([str(i), r['codigo'], r['pasajero'], f"{r['tipo_documento']}: {r['dni']}",
                              r['telefono'], str(asiento), r['metodo_pago'], f"S/ {float(r['total']):.2f}", r['estado']])
            elementos.append(tabla(filas, [22, 70, 110, 76, 58, 40, 48, 50, 65]))
            elementos.append(Spacer(1, 6))
        elementos.append(Spacer(1, 6))
        elementos.append(Paragraph(f'<b>Total de pasajeros:</b> {total_pax} &nbsp;&nbsp; '
                                   f'<b>Recaudación registrada:</b> S/ {total_monto:.2f}', normal))

    elementos.append(Spacer(1, 10))
    elementos.append(Paragraph('<b>Declaración:</b> Este documento presenta el registro de pasajeros y reservas almacenado por el sistema. '
                               'La validación final de requisitos y formato ante la autoridad de transporte corresponde al operador del servicio.', normal))

    # Un croquis por cada ruta (todas las rutas), cada uno en su propia página.
    primera = True
    for ru in rutas:
        cap = int(ru['capacidad'])
        pisos = int(ru['pisos'] or 1)
        ocupados = set(ocupados_ruta.get(ru['id'], {}).keys())
        # Todas las rutas usan la misma distribución: bloque superior (1..p2) y bloque inferior (resto).
        # Las de 1 piso solo cambian los rótulos, porque no tienen piso 2 separado en la venta.
        p2 = piso2_max(cap, 2)
        if pisos >= 2:
            rot_sup, rot_inf = f'Piso 2 · asientos 1 – {p2}', f'Piso 1 · asientos {p2 + 1} – {cap}'
        else:
            rot_sup, rot_inf = f'Asientos 1 – {p2}', f'Asientos {p2 + 1} – {cap}'
        bloques = [{'titulo': rot_sup, 'piso': 2, 'filas': disposicion_piso(1, p2, 2),
                    'especiales': [(3, 2, 3, 'ESCALERA')] if p2 > 12 else []}]
        if p2 < cap:
            bloques.append({'titulo': rot_inf, 'piso': 1, 'filas': disposicion_piso(p2 + 1, cap, 1),
                            'especiales': [(0, 0, 1, 'ESCALERA'), (1, 0, 1, 'BAÑO')]})
        if not primera:
            elementos.append(PageBreak())
        elementos.append(Paragraph('CROQUIS DE DISTRIBUCIÓN DE ASIENTOS', titulo))
        if primera:
            elementos.append(Paragraph('Una página por ruta. Rojo = vendido, amarillo = disponible. '
                                       'El número de asientos corresponde a la capacidad configurada en Rutas y precios.', subtitulo))
        primera = False
        elementos.append(Paragraph(f"{xesc(ru['origen'])} → {xesc(ru['destino'])} · {xesc(ru['horario'])}"
                                   + (" · 2 pisos" if pisos >= 2 else " · 1 piso"), seccion))
        elementos.append(Croquis(f"{ru['origen']} → {ru['destino']}", bloques, cap, ocupados))

    def pie(canv, documento):
        canv.saveState()
        canv.setFont('Helvetica', 7); canv.setFillColor(colors.HexColor('#666666'))
        canv.drawString(28, 18, f'LLAMPAYEC · Manifiesto del {fecha}')
        canv.drawRightString(A4[0] - 28, 18, f'Página {documento.page}')
        canv.restoreState()

    doc.build(elementos, onFirstPage=pie, onLaterPages=pie)
    salida.seek(0)
    return salida.getvalue()


def crear_excel_reporte(fecha=None):
    if Workbook is None:
        raise RuntimeError("Falta openpyxl. Ejecuta: pip install openpyxl")
    fecha, reservas, rutas = datos_reporte(fecha)
    azul = '173B7A'
    encab_fill = PatternFill('solid', fgColor=azul)
    encab_font = Font(bold=True, color='FFFFFF')
    borde = Border(*(Side(style='thin', color='B7C1D1'),) * 4)
    FORMATO_SOLES = '"S/ "#,##0.00'

    def preparar(ws, encabezados, nombre_tabla, filas, formatos=None):
        """Escribe encabezados y filas con estilo explícito (no depende del estilo de tabla)."""
        ws.append(encabezados)
        for c in ws[1]:
            c.fill = encab_fill; c.font = encab_font; c.border = borde
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.row_dimensions[1].height = 30
        for fila in filas:
            ws.append(fila)
        for fila in ws.iter_rows(min_row=2, max_row=ws.max_row):
            for c in fila:
                c.border = borde
                c.alignment = Alignment(vertical='center')
                if formatos and c.column in formatos:
                    c.number_format = formatos[c.column]
        ultima = ws.max_row
        if filas:
            tabla_xl = ExcelTable(displayName=nombre_tabla, ref=f'A1:{get_column_letter(len(encabezados))}{ultima}')
            tabla_xl.tableStyleInfo = TableStyleInfo(name='TableStyleLight1', showRowStripes=False)
            ws.add_table(tabla_xl)
        ws.freeze_panes = 'A2'
        for idx, _ in enumerate(encabezados, 1):
            letra = get_column_letter(idx)
            largo = max(len(str(ws.cell(row=r, column=idx).value or '')) for r in range(1, ultima + 1))
            ws.column_dimensions[letra].width = max(11, min(largo + 3, 38))
        ws.page_setup.orientation = 'landscape'
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.print_title_rows = '1:1'
        ws.sheet_view.showGridLines = False

    # Hoja 1: pasajeros confirmados del día
    wb = Workbook()
    ws = wb.active
    ws.title = 'Pasajeros'
    filas = []
    for r in reservas:
        filas.append([r['id'], r['codigo'], r['fecha'], r['origen'], r['destino'], r['horario'], r['pasajero'],
                      r['tipo_documento'], r['dni'], r['telefono'], r['asiento'], r['metodo_pago'],
                      float(r['total']), r['estado']])
    preparar(ws, ['ID', 'Código', 'Fecha', 'Origen', 'Destino', 'Horario', 'Pasajero', 'Tipo documento',
                  'Documento', 'Teléfono', 'Asiento', 'Método de pago', 'Tarifa', 'Estado'],
             'TablaPasajeros', filas, {13: FORMATO_SOLES, 11: '0'})
    if not filas:
        ws.cell(row=2, column=1, value='Sin pasajeros confirmados para esta fecha.')
        ws.cell(row=2, column=1).font = Font(italic=True, color='666666')
    for col, ancho in {7: 34, 9: 14, 14: 12}.items():
        ws.column_dimensions[get_column_letter(col)].width = ancho

    # Hoja 2: ventas por ruta con total
    wf = wb.create_sheet('Finanzas')
    grupos = {}
    for r in reservas:
        grupos.setdefault(f"{r['origen']} → {r['destino']}", []).append(r)
    filas = []
    for ruta, rows in grupos.items():
        monto = sum(float(x['total']) for x in rows)
        filas.append([fecha, ruta, len(rows), round(monto / len(rows), 2), round(monto, 2)])
    preparar(wf, ['Fecha', 'Ruta', 'Pasajeros', 'Tarifa promedio', 'Recaudación'], 'TablaFinanzas', filas,
             {4: FORMATO_SOLES, 5: FORMATO_SOLES, 3: '0'})
    if not filas:
        wf.cell(row=2, column=1, value='Sin ventas confirmadas para esta fecha.')
        wf.cell(row=2, column=1).font = Font(italic=True, color='666666')
    total_pax = len(reservas)
    total_monto = round(sum(float(r['total']) for r in reservas), 2)
    fila_total = wf.max_row + 2
    wf.cell(row=fila_total, column=2, value='TOTAL').font = Font(bold=True)
    wf.cell(row=fila_total, column=3, value=total_pax).font = Font(bold=True)
    celda_total = wf.cell(row=fila_total, column=5, value=total_monto)
    celda_total.font = Font(bold=True); celda_total.number_format = FORMATO_SOLES
    for col in (2, 3, 5):
        wf.cell(row=fila_total, column=col).border = Border(top=Side(style='medium', color=azul))
    wf.column_dimensions['B'].width = 30

    # Hoja 3: asientos de cada ruta según su capacidad
    wa = wb.create_sheet('Asientos')
    por_ruta = _ocupados_por_ruta(reservas)
    filas = []
    for ru in rutas:
        ocupados = por_ruta.get(ru['id'], {})
        ruta_txt = f"{ru['origen']} → {ru['destino']}"
        cap = int(ru['capacidad'])
        p2 = piso2_max(cap, 2)
        for n in range(1, cap + 1):
            r = ocupados.get(n)
            piso = 1 if n > p2 else 2
            filas.append([ruta_txt, n, piso, 'OCUPADO' if r else 'LIBRE', r['pasajero'] if r else '',
                          f"{r['tipo_documento']}: {r['dni']}" if r else '', r['telefono'] if r else '',
                          r['codigo'] if r else '', fecha])
    preparar(wa, ['Ruta', 'Asiento', 'Piso', 'Estado', 'Pasajero', 'Documento', 'Teléfono', 'Código', 'Fecha'],
             'TablaAsientos', filas, {2: '0'})
    rojo = PatternFill('solid', fgColor='F8D7DA'); verde = PatternFill('solid', fgColor='D4EDDA')
    for fila in wa.iter_rows(min_row=2, max_row=wa.max_row):
        estado = fila[3]
        estado.fill = rojo if estado.value == 'OCUPADO' else verde
        estado.alignment = Alignment(horizontal='center', vertical='center')
    wa.column_dimensions['A'].width = 30
    wa.column_dimensions['E'].width = 34

    # Hoja 4: catálogo de rutas, precios y capacidad
    wr = wb.create_sheet('Rutas')
    filas = [[r['id'], r['origen'], r['destino'], float(r['precio']), r['horario'], r['duracion'], int(r['capacidad'])]
             for r in rutas]
    preparar(wr, ['ID', 'Origen', 'Destino', 'Precio', 'Horario', 'Duración', 'Capacidad (asientos)'], 'TablaRutas', filas,
             {4: FORMATO_SOLES, 7: '0'})

    salida = BytesIO(); wb.save(salida); salida.seek(0)
    return salida.getvalue()


# ------------------------------------------------------------
# API - Lógica de reservas
# ------------------------------------------------------------
def api_contacto():
    """Datos de contacto editables desde el panel admin."""
    conn = conectar()
    filas = conn.execute("SELECT clave, valor FROM contacto").fetchall()
    conn.close()
    datos = dict(CONTACTO_DEFECTO)
    datos.update({f["clave"]: f["valor"] for f in filas})
    # El RUC no se guarda en contacto: es el mismo dato de empresa que usa el boleto.
    datos["ruc"] = leer_empresa()["ruc"]
    return datos

def api_guardar_contacto(datos):
    limpio = {
        "telefono": str(datos.get("telefono", "")).strip(),
        "email": str(datos.get("email", "")).strip(),
        "direccion": str(datos.get("direccion", "")).strip(),
    }
    ruc = re.sub(r"\s", "", str(datos.get("ruc", "")))
    if not re.fullmatch(r"\+?[\d ]{6,25}", limpio["telefono"]):
        return {"ok": False, "error": "Teléfono: usa solo números y espacios (ej: +51 999 999 999)."}
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", limpio["email"]):
        return {"ok": False, "error": "Correo electrónico no válido."}
    if not 1 <= len(limpio["direccion"]) <= 120:
        return {"ok": False, "error": "La dirección debe tener entre 1 y 120 caracteres."}
    if ruc and not validar_ruc(ruc):
        return {"ok": False, "error": "RUC no válido (11 dígitos, empieza con 10, 15, 16, 17 o 20)."}
    conn = conectar()
    for clave, valor in limpio.items():
        conn.execute("INSERT INTO contacto (clave, valor) VALUES (?,?) "
                     "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (clave, valor))
    # El RUC solo se actualiza si viene en la petición: guardar contacto sin RUC no debe borrarlo.
    if "ruc" in datos:
        conn.execute("INSERT INTO empresa (clave, valor) VALUES ('ruc', ?) "
                     "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (ruc,))
    else:
        ruc = leer_empresa(conn)["ruc"]
    conn.commit()
    conn.close()
    limpio["ruc"] = ruc
    return {"ok": True, "mensaje": "Datos de contacto guardados.", "datos": limpio}

def api_rutas():
    conn = conectar()
    filas = conn.execute("SELECT * FROM rutas ORDER BY id").fetchall()
    conn.close()
    return [dict(f) for f in filas]

PISO2_HASTA = 48  # con 2 pisos, el piso 2 toma los asientos 1..48; el piso 1 toma desde el 49

def piso2_max(capacidad, pisos):
    """Último asiento del piso 2 (asientos 1..N). Con 2 pisos, el piso 1 son los asientos N+1 en adelante."""
    if int(pisos or 1) < 2:
        return capacidad
    return min(capacidad, PISO2_HASTA)


def precio_asiento(ruta, asiento):
    """Tarifa de un asiento: el precio de su piso (piso 2 = asientos 1..48, piso 1 = resto) si ese piso tiene precio; si no, el general.
    Aplica a todas las rutas, sean de 1 o de 2 pisos."""
    general = float(ruta["precio"])
    piso = 1 if asiento > piso2_max(int(ruta["capacidad"]), 2) else 2
    valor = ruta["precio_piso1"] if piso == 1 else ruta["precio_piso2"]
    return float(valor) if valor is not None else general


def precio_opcional(valor):
    """Precio por piso: vacío = None (usa el precio general). Lanza ValueError si no es válido."""
    if valor is None or str(valor).strip() == "":
        return None
    p = round(float(valor), 2)
    if not 0 < p <= 1000:
        raise ValueError
    return p

def api_asientos(ruta_id, fecha=None):
    """Asientos ocupados de una ruta en una fecha (por defecto hoy), para el mapa en tiempo real."""
    conn = conectar()
    ruta = conn.execute("SELECT capacidad, pisos FROM rutas WHERE id=?", (ruta_id,)).fetchone()
    hoy = fecha if fecha and re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha) else datetime.now().strftime("%Y-%m-%d")
    filas = conn.execute(
        "SELECT asiento FROM reservas WHERE ruta_id=? AND fecha=? AND estado='CONFIRMADA'",
        (ruta_id, hoy)
    ).fetchall()
    conn.close()
    if not ruta:
        return {"total": 0, "ocupados": [], "libres": 0, "error": "La ruta no existe"}
    total = int(ruta["capacidad"])
    pisos = int(ruta["pisos"] or 1)
    ocupados = [f["asiento"] for f in filas]
    return {"total": total, "pisos": pisos, "piso2_max": piso2_max(total, 2),
            "ocupados": ocupados, "libres": total - len(ocupados)}

def api_reservar(datos, caja=None, cliente_correo=None):
    """Procesa la reserva: valida, verifica asiento libre y guarda."""
    campos = ["ruta_id", "asiento", "pasajero", "tipo_documento", "dni", "telefono", "metodo_pago"]
    for c in campos:
        if c not in datos or str(datos[c]).strip() == "":
            return {"ok": False, "error": f"Falta el campo: {c}"}

    try:
        ruta_id = int(datos["ruta_id"])
        asiento = int(datos["asiento"])
    except (TypeError, ValueError):
        return {"ok": False, "error": "Ruta o asiento no válidos."}

    tipo_documento = str(datos["tipo_documento"]).upper().strip()
    documento = str(datos["dni"]).strip()
    reglas_documento = {
        "DNI": r"\d{8}",
        "CE": r"\d{9}",
        "PASAPORTE": r"\d{8,9}"
    }
    if tipo_documento not in reglas_documento:
        return {"ok": False, "error": "Tipo de documento no válido"}
    if not re.fullmatch(reglas_documento[tipo_documento], documento):
        requisitos = {"DNI": "8 dígitos", "CE": "9 dígitos", "PASAPORTE": "8 o 9 dígitos"}
        return {"ok": False, "error": f"{tipo_documento}: el documento debe tener {requisitos[tipo_documento]}"}
    if not re.fullmatch(r"\d{6,15}", str(datos["telefono"])):
        return {"ok": False, "error": "Telefono invalido"}

    conn = conectar()
    ruta = conn.execute("SELECT * FROM rutas WHERE id=?", (ruta_id,)).fetchone()
    if not ruta:
        conn.close()
        return {"ok": False, "error": "La ruta no existe"}
    if not (1 <= asiento <= int(ruta["capacidad"])):
        conn.close()
        return {"ok": False, "error": f"Número de asiento inválido. Esta ruta tiene {ruta['capacidad']} asientos."}
    precio_real = precio_asiento(ruta, asiento)
    canal, recibido, vuelto = "WEB", None, None
    if caja is not None:
        canal = "CAJA"
        if datos["metodo_pago"] not in METODOS_CAJA:
            conn.close()
            return {"ok": False, "error": "Método de pago no válido para caja."}
        precio = precio_real
        if datos["metodo_pago"] == "Efectivo":
            try:
                recibido = round(float(caja.get("monto_recibido")), 2)
            except (TypeError, ValueError):
                conn.close()
                return {"ok": False, "error": "Monto recibido no válido."}
            if recibido < precio:
                conn.close()
                return {"ok": False, "error": "Monto insuficiente"}
            vuelto = round(recibido - precio, 2)
        else:
            recibido, vuelto = precio, 0.0
    elif datos["metodo_pago"] == "Efectivo":
        conn.close()
        return {"ok": False, "error": "El efectivo solo se cobra en caja."}
    cliente_ruc = cliente_razon = None
    if caja is not None and str(caja.get("cliente_ruc", "")).strip():
        cliente_ruc = str(caja["cliente_ruc"]).strip()
        if not validar_ruc(cliente_ruc):
            conn.close()
            return {"ok": False, "error": "RUC del cliente no válido (11 dígitos)."}
        cliente_razon = str(caja.get("cliente_razon", "")).strip()[:120]
        if not cliente_razon:
            conn.close()
            return {"ok": False, "error": "Escribe la razón social del cliente."}
    base_imp, igv_monto = calcular_igv(precio_real, leer_empresa(conn))

    hoy = datetime.now().strftime("%Y-%m-%d")
    ocupado = conn.execute(
        "SELECT id FROM reservas WHERE ruta_id=? AND asiento=? AND fecha=? AND estado='CONFIRMADA'",
        (ruta_id, asiento, hoy)
    ).fetchone()
    if ocupado:
        conn.close()
        return {"ok": False, "error": f"El asiento {asiento} acaba de ser ocupado. Elige otro."}

    codigo = "LLA-" + datetime.now().strftime("%y%m%d") + str(asiento).zfill(2) + str(ruta_id) + secrets.token_hex(2).upper()
    try:
        conn.execute("""
            INSERT INTO reservas (codigo, ruta_id, asiento, pasajero, tipo_documento, dni, telefono,
                                  metodo_pago, total, fecha, canal, monto_recibido, vuelto,
                                  cliente_ruc, cliente_razon, base_imponible, igv, cliente_correo)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (codigo, ruta_id, asiento, str(datos["pasajero"]).strip(),
              tipo_documento, documento, datos["telefono"], datos["metodo_pago"],
              precio_real, hoy, canal, recibido, vuelto,
              cliente_ruc, cliente_razon, base_imp, igv_monto, cliente_correo))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return {"ok": False, "error": "El asiento ya esta reservado"}
    conn.close()

    resultado = {"ok": True, "codigo": codigo, "total": precio_real,
                 "mensaje": "Reserva confirmada. Codigo: " + codigo}
    if caja is not None:
        resultado.update({"recibido": recibido, "vuelto": vuelto, "base": base_imp, "igv": igv_monto,
                          "cliente_ruc": cliente_ruc, "cliente_razon": cliente_razon})
    return resultado

def api_reservas():
    """Panel admin: reservas del dia."""
    conn = conectar()
    hoy = datetime.now().strftime("%Y-%m-%d")
    filas = conn.execute("""
        SELECT r.codigo, r.asiento, r.pasajero, r.tipo_documento, r.dni, r.telefono,
               r.metodo_pago, r.total, r.estado, r.fecha, ru.origen, ru.destino, ru.horario
        FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id
        WHERE r.fecha = ? ORDER BY r.id DESC
    """, (hoy,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]

# ------------------------------------------------------------
# SERVIDOR HTTP
# ------------------------------------------------------------
def registrar_auditoria(conn, usuario, accion, detalle):
    conn.execute("INSERT INTO auditoria (fecha, usuario, accion, detalle) VALUES (?,?,?,?)",
                 (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), usuario, accion, detalle))

def resumen_ventas():
    ahora = datetime.now()
    hoy = ahora.strftime("%Y-%m-%d")
    inicio_semana = (ahora - timedelta(days=ahora.weekday())).strftime("%Y-%m-%d")
    inicio_mes = ahora.replace(day=1).strftime("%Y-%m-%d")
    hace_7 = (ahora - timedelta(days=6)).strftime("%Y-%m-%d")
    conn = conectar()
    def periodo(desde):
        f = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(total),0) s FROM reservas "
                         "WHERE estado='CONFIRMADA' AND fecha>=?", (desde,)).fetchone()
        return {"boletos": f["n"], "ingresos": round(f["s"], 2)}
    hoy_p = periodo(hoy)
    semana_p = periodo(inicio_semana)
    mes = periodo(inicio_mes)
    mes["promedio"] = round(mes["ingresos"] / mes["boletos"], 2) if mes["boletos"] else 0
    reemb = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(total),0) s FROM reservas "
                         "WHERE estado='REEMBOLSADA' AND fecha>=?", (inicio_mes,)).fetchone()
    metodos = conn.execute("SELECT metodo_pago, COUNT(*) boletos, COALESCE(SUM(total),0) ingresos "
                           "FROM reservas WHERE estado='CONFIRMADA' AND fecha>=? "
                           "GROUP BY metodo_pago ORDER BY ingresos DESC", (inicio_mes,)).fetchall()
    rutas = conn.execute("SELECT ru.origen || ' → ' || ru.destino AS ruta, COUNT(*) boletos, "
                         "COALESCE(SUM(r.total),0) ingresos FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id "
                         "WHERE r.estado='CONFIRMADA' AND r.fecha>=? GROUP BY ru.id ORDER BY ingresos DESC",
                         (inicio_mes,)).fetchall()
    dias = conn.execute("SELECT fecha, COUNT(*) boletos, COALESCE(SUM(total),0) ingresos FROM reservas "
                        "WHERE estado='CONFIRMADA' AND fecha>=? GROUP BY fecha ORDER BY fecha", (hace_7,)).fetchall()
    conn.close()
    return {
        "hoy": hoy_p,
        "semana": semana_p,
        "mes": mes,
        "reembolsos_mes": {"boletos": reemb["n"], "monto": round(reemb["s"], 2)},
        "metodos_mes": [dict(x) for x in metodos],
        "rutas_mes": [dict(x) for x in rutas],
        "ultimos_dias": [dict(x) for x in dias],
    }

def listar_reservas_admin(fecha, ruta_id, estado):
    sql = """SELECT r.codigo, r.asiento, r.pasajero, r.tipo_documento, r.dni, r.telefono,
                    r.metodo_pago, r.total, r.estado, r.abordado, r.fecha, r.ruta_id,
                    ru.origen, ru.destino, ru.horario
             FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id WHERE r.fecha = ?"""
    params = [fecha]
    if ruta_id:
        sql += " AND r.ruta_id = ?"; params.append(ruta_id)
    if estado and estado != "TODAS":
        sql += " AND r.estado = ?"; params.append(estado)
    sql += " ORDER BY ru.id, r.asiento"
    conn = conectar()
    filas = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(f) for f in filas]

ETIQUETAS_ACCION = {"abordar": "pasajero abordó", "quitar_abordaje": "abordaje retirado",
                    "cancelar": "reserva cancelada", "reembolsar": "reserva reembolsada"}

def accion_reserva(datos, usuario):
    codigo = str(datos.get("codigo", "")).strip()
    accion = str(datos.get("accion", ""))
    if accion not in ETIQUETAS_ACCION:
        return {"ok": False, "error": "Acción no válida."}
    conn = conectar()
    r = conn.execute("SELECT codigo, pasajero, asiento, estado, abordado FROM reservas WHERE codigo=?",
                     (codigo,)).fetchone()
    if not r:
        conn.close()
        return {"ok": False, "error": "Reserva no encontrada."}
    estado, abordado = r["estado"], r["abordado"]
    if accion == "abordar":
        if estado != "CONFIRMADA":
            conn.close(); return {"ok": False, "error": "Solo se puede abordar una reserva confirmada."}
        abordado = 1
    elif accion == "quitar_abordaje":
        abordado = 0
    else:
        if estado != "CONFIRMADA":
            conn.close(); return {"ok": False, "error": "Solo se puede cancelar o reembolsar una reserva confirmada."}
        estado = "CANCELADA" if accion == "cancelar" else "REEMBOLSADA"
        abordado = 0
    conn.execute("UPDATE reservas SET estado=?, abordado=? WHERE codigo=?", (estado, abordado, codigo))
    registrar_auditoria(conn, usuario, accion.upper(), f"{codigo} · {r['pasajero']} · asiento {r['asiento']}")
    conn.commit()
    conn.close()
    return {"ok": True, "mensaje": f"{codigo}: {ETIQUETAS_ACCION[accion]}."}

def mover_asiento(datos, usuario):
    """Cambia el asiento de una reserva confirmada a otro libre (misma ruta y fecha)."""
    codigo = str(datos.get("codigo", "")).strip()
    try:
        nuevo = int(datos.get("asiento_nuevo"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Asiento no válido."}
    conn = conectar()
    r = conn.execute("""SELECT r.codigo, r.pasajero, r.asiento, r.estado, r.ruta_id, r.fecha, ru.capacidad
                        FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id WHERE r.codigo=?""",
                     (codigo,)).fetchone()
    if not r:
        conn.close()
        return {"ok": False, "error": "Reserva no encontrada."}
    if r["estado"] != "CONFIRMADA":
        conn.close()
        return {"ok": False, "error": "Solo se puede cambiar el asiento de una reserva confirmada."}
    anterior = int(r["asiento"])
    if nuevo == anterior:
        conn.close()
        return {"ok": False, "error": "El pasajero ya está en ese asiento."}
    if not (1 <= nuevo <= int(r["capacidad"])):
        conn.close()
        return {"ok": False, "error": f"Número de asiento inválido. Esta ruta tiene {r['capacidad']} asientos."}
    ocupado = conn.execute(
        "SELECT codigo FROM reservas WHERE ruta_id=? AND asiento=? AND fecha=? AND estado='CONFIRMADA'",
        (r["ruta_id"], nuevo, r["fecha"])
    ).fetchone()
    if ocupado:
        conn.close()
        return {"ok": False, "error": f"El asiento {nuevo} ya está ocupado."}
    try:
        conn.execute("UPDATE reservas SET asiento=? WHERE codigo=?", (nuevo, codigo))
        registrar_auditoria(conn, usuario, "CAMBIAR ASIENTO",
                            f"{codigo} · {r['pasajero']} · asiento {anterior} → {nuevo}")
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
        conn.close()
        return {"ok": False, "error": f"El asiento {nuevo} ya está ocupado."}
    conn.close()
    return {"ok": True, "mensaje": f"{codigo}: pasajero movido del asiento {anterior} al {nuevo}."}

def guardar_ruta_admin(datos, usuario):
    origen = str(datos.get("origen", "")).strip()
    destino = str(datos.get("destino", "")).strip()
    horario = str(datos.get("horario", "")).strip()
    duracion = str(datos.get("duracion", "")).strip()
    try:
        precio = round(float(datos.get("precio")), 2)
    except (TypeError, ValueError):
        return {"ok": False, "error": "Precio no válido."}
    try:
        capacidad = int(datos.get("capacidad", CAPACIDAD_DEFECTO))
    except (TypeError, ValueError):
        return {"ok": False, "error": "La capacidad debe ser un número entero."}
    if not origen or not destino or len(origen) > 60 or len(destino) > 60:
        return {"ok": False, "error": "Origen y destino son obligatorios (máximo 60 caracteres)."}
    if not 0 < precio <= 1000:
        return {"ok": False, "error": "El precio debe estar entre S/ 0.01 y S/ 1000."}
    if not horario or len(horario) > 80 or not duracion or len(duracion) > 30:
        return {"ok": False, "error": "Horario y duración son obligatorios."}
    if capacidad < 1:
        return {"ok": False, "error": "La capacidad debe ser de al menos 1 asiento."}
    try:
        pisos = int(datos.get("pisos", 1))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Los pisos deben ser 1 o 2."}
    if pisos not in (1, 2):
        return {"ok": False, "error": "Los pisos deben ser 1 o 2."}
    try:
        precio_piso1 = precio_opcional(datos.get("precio_piso1"))
        precio_piso2 = precio_opcional(datos.get("precio_piso2"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Los precios por piso deben estar entre S/ 0.01 y S/ 1000."}
    detalle = f"{origen} → {destino} · S/ {precio:.2f} · {horario} · {capacidad} asientos"
    conn = conectar()
    if datos.get("id"):
        try:
            rid = int(datos["id"])
        except (TypeError, ValueError):
            conn.close(); return {"ok": False, "error": "Ruta no válida."}
        if not conn.execute("SELECT id FROM rutas WHERE id=?", (rid,)).fetchone():
            conn.close(); return {"ok": False, "error": "La ruta no existe."}
        hoy = datetime.now().strftime("%Y-%m-%d")
        maximo = conn.execute(
            "SELECT MAX(asiento) m FROM reservas WHERE ruta_id=? AND fecha=? AND estado='CONFIRMADA'", (rid, hoy)
        ).fetchone()["m"]
        if maximo and maximo > capacidad:
            conn.close()
            return {"ok": False, "error": f"No puedes bajar la capacidad a {capacidad}: el asiento {maximo} ya está vendido hoy."}
        conn.execute("UPDATE rutas SET origen=?, destino=?, precio=?, horario=?, duracion=?, capacidad=?, pisos=?, precio_piso1=?, precio_piso2=? WHERE id=?",
                     (origen, destino, precio, horario, duracion, capacidad, pisos, precio_piso1, precio_piso2, rid))
        registrar_auditoria(conn, usuario, "EDITAR_RUTA", detalle)
        mensaje = "Ruta actualizada. Las reservas ya vendidas conservan su tarifa original."
    else:
        conn.execute("INSERT INTO rutas (origen, destino, precio, horario, duracion, capacidad, pisos, precio_piso1, precio_piso2) VALUES (?,?,?,?,?,?,?,?,?)",
                     (origen, destino, precio, horario, duracion, capacidad, pisos, precio_piso1, precio_piso2))
        registrar_auditoria(conn, usuario, "CREAR_RUTA", detalle)
        mensaje = "Ruta creada."
    conn.commit()
    conn.close()
    return {"ok": True, "mensaje": mensaje}

def guardar_precios_piso(datos, usuario):
    """Cajera o admin: fija el precio del piso 1 y del piso 2 de una ruta (vacío = precio general)."""
    try:
        rid = int(datos.get("ruta_id"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Ruta no válida."}
    try:
        precio_piso1 = precio_opcional(datos.get("precio_piso1"))
        precio_piso2 = precio_opcional(datos.get("precio_piso2"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "Los precios por piso deben estar entre S/ 0.01 y S/ 1000."}
    conn = conectar()
    ruta = conn.execute("SELECT origen, destino, precio, pisos FROM rutas WHERE id=?", (rid,)).fetchone()
    if not ruta:
        conn.close()
        return {"ok": False, "error": "La ruta no existe."}
    conn.execute("UPDATE rutas SET precio_piso1=?, precio_piso2=? WHERE id=?", (precio_piso1, precio_piso2, rid))
    general = float(ruta["precio"])
    detalle = (f"{ruta['origen']} → {ruta['destino']} · 1 piso: S/ {(precio_piso1 or general):.2f}"
               f" · 2 piso: S/ {(precio_piso2 or general):.2f}")
    registrar_auditoria(conn, usuario, "PRECIO_PISOS", detalle)
    conn.commit()
    conn.close()
    return {"ok": True, "mensaje": "Precios por piso guardados. Las ventas ya hechas conservan su tarifa."}

def listar_auditoria():
    conn = conectar()
    filas = conn.execute("SELECT fecha, usuario, accion, detalle FROM auditoria ORDER BY id DESC LIMIT 200").fetchall()
    conn.close()
    return [dict(f) for f in filas]

def cierre_caja(fecha):
    conn = conectar()
    def sumas(metodos):
        marcas = ",".join("?" * len(metodos))
        filas = conn.execute(
            f"SELECT metodo_pago, COUNT(*) boletos, COALESCE(SUM(total),0) monto FROM reservas "
            f"WHERE fecha=? AND estado='CONFIRMADA' AND metodo_pago IN ({marcas}) GROUP BY metodo_pago",
            [fecha, *metodos]).fetchall()
        por = {f["metodo_pago"]: {"metodo_pago": f["metodo_pago"], "boletos": f["boletos"], "monto": round(f["monto"], 2)} for f in filas}
        return [por.get(m, {"metodo_pago": m, "boletos": 0, "monto": 0.0}) for m in metodos]
    def reembolsado(metodos):
        marcas = ",".join("?" * len(metodos))
        r = conn.execute(
            f"SELECT COALESCE(SUM(total),0) s FROM reservas WHERE fecha=? AND estado='REEMBOLSADA' "
            f"AND metodo_pago IN ({marcas})", [fecha, *metodos]).fetchone()
        return round(r["s"], 2)
    ef = conn.execute(
        "SELECT COALESCE(SUM(COALESCE(monto_recibido,total)),0) rec, COALESCE(SUM(COALESCE(vuelto,0)),0) vue "
        "FROM reservas WHERE fecha=? AND estado='CONFIRMADA' AND metodo_pago='Efectivo'", (fecha,)).fetchone()
    ventas = conn.execute(
        "SELECT codigo, pasajero, total, COALESCE(monto_recibido,total) recibido, COALESCE(vuelto,0) vuelto "
        "FROM reservas WHERE fecha=? AND estado='CONFIRMADA' AND metodo_pago='Efectivo' ORDER BY id", (fecha,)).fetchall()
    billeteras = sumas(["Yape", "Plin"])
    pasarelas = sumas(["Tarjeta", "PayPal"])
    reemb_ef = reembolsado(["Efectivo"])
    reemb_pa = reembolsado(["Tarjeta", "PayPal"])
    conn.close()
    recibido, vueltos = round(ef["rec"], 2), round(ef["vue"], 2)
    bruto_pa = round(sum(m["monto"] for m in pasarelas), 2)
    return {
        "fecha": fecha,
        "caja_fisica": {"recibido": recibido, "vueltos": vueltos, "reembolsos": reemb_ef,
                        "neto": round(recibido - vueltos - reemb_ef, 2)},
        "billeteras": {"metodos": billeteras, "total": round(sum(m["monto"] for m in billeteras), 2)},
        "pasarelas": {"metodos": pasarelas, "bruto": bruto_pa, "reembolsos": reemb_pa,
                      "neto": round(bruto_pa - reemb_pa, 2)},
        "ventas_efectivo": [dict(v) for v in ventas],
    }

def leer_permiso_cierre():
    """True si el admin activó que la cajera vea el cierre de caja."""
    conn = conectar()
    fila = conn.execute("SELECT valor FROM empresa WHERE clave='cajero_ve_cierre'").fetchone()
    conn.close()
    return bool(fila and fila["valor"] == "1")

def guardar_permiso_cierre(activo, actor):
    conn = conectar()
    conn.execute("INSERT INTO empresa (clave, valor) VALUES ('cajero_ve_cierre', ?) "
                 "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", ("1" if activo else "0",))
    registrar_auditoria(conn, actor, "PERMISO_CIERRE", "Cajera puede ver el cierre de caja: " + ("Sí" if activo else "No"))
    conn.commit()
    conn.close()
    return {"ok": True, "permitido": bool(activo),
            "mensaje": "La cajera ya puede ver el cierre de caja." if activo else "La cajera ya no ve el cierre de caja."}

def roles_para(metodo, ruta):
    """Qué roles pueden usar cada ruta. None = pública."""
    if ruta in ("/api/reservas", "/admin.html"):
        return ("ADMIN",)
    if ruta in ("/api/reporte/pdf", "/api/reporte/xlsx"):
        return ("ADMIN", "CAJERO")
    if ruta in ("/api/admin/cierre", "/api/caja/permiso-cierre"):
        return ("ADMIN", "CAJERO")
    if ruta.startswith("/api/admin/"):
        return ("ADMIN",)
    if metodo == "POST" and ruta == "/api/contacto":
        return ("ADMIN",)
    if ruta in ("/api/caja/venta", "/api/caja/ruc", "/api/caja/dni", "/api/caja/empresa", "/caja.html"):
        return ("ADMIN", "CAJERO")
    return None

PAGINA_ACCESO_DENEGADO = """<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Acceso Denegado | Llampayec</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;background:#0a1836;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0;padding:20px;text-align:center}
.caja{max-width:420px;border:1px solid #ff5c8a;border-radius:16px;padding:30px;background:rgba(255,45,120,.08)}
h1{color:#ff5c8a}a{color:#00e5ff;font-weight:700}</style></head>
<body><div class="caja"><h1>🚫 Acceso Denegado</h1><p>Tu cuenta no tiene permiso para ver esta página.</p>
<p><a href="/caja.html">Ir a la caja</a></p></div></body></html>"""

def cerrar_sesiones_de(usuario):
    for token in [t for t, u in USUARIOS_SESION.items() if u == usuario]:
        SESIONES.pop(token, None)
        USUARIOS_SESION.pop(token, None)
        SESION_ROL.pop(token, None)

def admins_activos(conn):
    return conn.execute("SELECT COUNT(*) n FROM usuarios WHERE rol='ADMIN' AND activo=1").fetchone()["n"]

def listar_usuarios():
    conn = conectar()
    filas = conn.execute("SELECT id, usuario, nombre, correo, rol, activo, creado FROM usuarios ORDER BY id").fetchall()
    conn.close()
    return [dict(f) for f in filas]

def accion_usuario(datos, actor):
    accion = str(datos.get("accion", ""))
    conn = conectar()
    try:
        def error(msg):
            return {"ok": False, "error": msg}
        if accion == "crear":
            nombre = str(datos.get("nombre", "")).strip()
            correo = str(datos.get("correo", "")).strip().lower()
            usuario = str(datos.get("usuario", "")).strip()
            clave = str(datos.get("contrasena", ""))
            rol = str(datos.get("rol", "")).upper()
            if not 2 <= len(nombre) <= 80:
                return error("Nombre: entre 2 y 80 caracteres.")
            if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", correo):
                return error("Correo electrónico no válido.")
            if not re.fullmatch(r"[A-Za-z0-9._-]{3,30}", usuario):
                return error("Usuario: 3 a 30 letras, números, punto, guion o guion bajo.")
            if len(clave) < 8:
                return error("La contraseña debe tener al menos 8 caracteres.")
            if rol not in ROLES_VALIDOS:
                return error("Rol no válido.")
            if conn.execute("SELECT 1 FROM usuarios WHERE usuario=? OR correo=?", (usuario, correo)).fetchone():
                return error("Ya existe un usuario con ese nombre de usuario o correo.")
            sal, clave_hash = hash_clave(clave)
            conn.execute("INSERT INTO usuarios (usuario, sal, clave_hash, creado, nombre, correo, rol, activo) "
                         "VALUES (?,?,?,?,?,?,?,1)",
                         (usuario, sal, clave_hash, datetime.now().isoformat(timespec="seconds"), nombre, correo, rol))
            registrar_auditoria(conn, actor, "CREAR_USUARIO", f"{usuario} · {rol} · {nombre}")
            conn.commit()
            return {"ok": True, "mensaje": f"Usuario {usuario} creado como {rol}."}

        try:
            uid = int(datos.get("id"))
        except (TypeError, ValueError):
            return error("Usuario no válido.")
        fila = conn.execute("SELECT id, usuario, rol, activo FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not fila:
            return error("Usuario no encontrado.")
        es_yo = fila["usuario"] == actor
        if accion == "desactivar":
            if es_yo:
                return error("No puedes desactivar tu propia cuenta.")
            if fila["rol"] == "ADMIN" and fila["activo"] and admins_activos(conn) <= 1:
                return error("Debe quedar al menos un administrador activo.")
            conn.execute("UPDATE usuarios SET activo=0 WHERE id=?", (uid,))
            registrar_auditoria(conn, actor, "DESACTIVAR_USUARIO", fila["usuario"])
            mensaje = f"Acceso de {fila['usuario']} desactivado."
        elif accion == "activar":
            conn.execute("UPDATE usuarios SET activo=1 WHERE id=?", (uid,))
            registrar_auditoria(conn, actor, "ACTIVAR_USUARIO", fila["usuario"])
            mensaje = f"Acceso de {fila['usuario']} activado."
        elif accion == "rol":
            rol = str(datos.get("rol", "")).upper()
            if rol not in ROLES_VALIDOS:
                return error("Rol no válido.")
            if es_yo and rol != "ADMIN":
                return error("No puedes quitarte tu propio rol de administrador.")
            if fila["rol"] == "ADMIN" and rol != "ADMIN" and fila["activo"] and admins_activos(conn) <= 1:
                return error("Debe quedar al menos un administrador activo.")
            conn.execute("UPDATE usuarios SET rol=? WHERE id=?", (rol, uid))
            registrar_auditoria(conn, actor, "CAMBIAR_ROL", f"{fila['usuario']} → {rol}")
            mensaje = f"Rol de {fila['usuario']} cambiado a {rol}."
        elif accion == "clave":
            clave = str(datos.get("contrasena", ""))
            if len(clave) < 8:
                return error("La contraseña debe tener al menos 8 caracteres.")
            sal, clave_hash = hash_clave(clave)
            conn.execute("UPDATE usuarios SET sal=?, clave_hash=? WHERE id=?", (sal, clave_hash, uid))
            registrar_auditoria(conn, actor, "CAMBIAR_CLAVE", fila["usuario"])
            mensaje = f"Contraseña de {fila['usuario']} actualizada."
        else:
            return error("Acción no válida.")
        conn.commit()
        if accion in ("desactivar", "rol", "clave") and not es_yo:
            cerrar_sesiones_de(fila["usuario"])
        return {"ok": True, "mensaje": mensaje}
    finally:
        conn.close()

def leer_empresa(conn=None):
    propio = conn is None
    c = conn or conectar()
    filas = c.execute("SELECT clave, valor FROM empresa").fetchall()
    if propio:
        c.close()
    datos = dict(EMPRESA_DEFECTO)
    datos.update({f["clave"]: f["valor"] for f in filas})
    return datos

def guardar_empresa(datos, actor):
    limpio = {
        "ruc": re.sub(r"\s", "", str(datos.get("ruc", ""))),
        "razon_social": str(datos.get("razon_social", "")).strip(),
        "direccion": str(datos.get("direccion", "")).strip(),
        "telefono": str(datos.get("telefono", "")).strip(),
        "ruc_api_url": str(datos.get("ruc_api_url", "")).strip(),
        "dni_api_url": str(datos.get("dni_api_url", "")).strip(),
    }
    if limpio["ruc"] and not validar_ruc(limpio["ruc"]):
        return {"ok": False, "error": "RUC de la empresa no válido (11 dígitos, empieza con 10, 15, 16, 17 o 20)."}
    if len(limpio["razon_social"]) > 120 or len(limpio["direccion"]) > 160 or len(limpio["telefono"]) > 40:
        return {"ok": False, "error": "Revisa la longitud de razón social, dirección o teléfono."}
    for campo in ("ruc_api_url", "dni_api_url"):
        if limpio[campo] and not re.match(r"https?://", limpio[campo]):
            return {"ok": False, "error": "Las URL de consulta deben empezar con https://"}
    try:
        tasa = float(str(datos.get("igv_tasa", "18")).replace(",", "."))
    except ValueError:
        return {"ok": False, "error": "La tasa de IGV debe ser un número."}
    if not 0 <= tasa <= 100:
        return {"ok": False, "error": "La tasa de IGV debe estar entre 0 y 100."}
    limpio["igv_tasa"] = str(tasa).rstrip("0").rstrip(".") if "." in str(tasa) else str(tasa)
    for campo in ("ruc_api_token", "dni_api_token"):
        valor = str(datos.get(campo, "")).strip()
        if valor:
            limpio[campo] = valor
    conn = conectar()
    for clave, valor in limpio.items():
        conn.execute("INSERT INTO empresa (clave, valor) VALUES (?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                     (clave, valor))
    registrar_auditoria(conn, actor, "ACTUALIZAR_EMPRESA", limpio["razon_social"] or "datos de la empresa")
    conn.commit()
    conn.close()
    return {"ok": True, "mensaje": "Datos de la empresa guardados."}

def validar_ruc(ruc):
    return bool(re.fullmatch(r"(10|15|16|17|20)\d{9}", ruc or ""))

def calcular_igv(total, empresa):
    """El precio ya incluye IGV: base = total / (1 + tasa)."""
    tasa = float(empresa.get("igv_tasa") or 0) / 100
    if tasa <= 0:
        return round(total, 2), 0.0
    base = round(total / (1 + tasa), 2)
    return base, round(total - base, 2)

def consultar_ruc(numero):
    if not validar_ruc(numero):
        return {"ok": False, "error": "RUC no válido (11 dígitos)."}
    empresa = leer_empresa()
    url = empresa.get("ruc_api_url", "")
    if not url:
        return {"ok": False, "error": "La consulta automática de RUC no está configurada. Escribe la razón social a mano."}
    peticion = urllib.request.Request(
        url + ("&" if "?" in url else "?") + urlencode({"numero": numero}),
        headers={"Accept": "application/json", "Authorization": "Bearer " + empresa.get("ruc_api_token", "")})
    try:
        with urllib.request.urlopen(peticion, timeout=8) as r:
            datos = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, ValueError, OSError):
        return {"ok": False, "error": "No se pudo consultar el RUC. Escribe la razón social a mano."}
    nombre = datos.get("razonSocial") or datos.get("razon_social") or datos.get("nombre") if isinstance(datos, dict) else None
    if not nombre:
        return {"ok": False, "error": "No se encontró razón social para ese RUC. Escríbela a mano."}
    return {"ok": True, "razon_social": str(nombre)}

def consultar_dni(numero):
    if not re.fullmatch(r"\d{8}", numero or ""):
        return {"ok": False, "error": "DNI no válido (8 dígitos)."}
    empresa = leer_empresa()
    url = empresa.get("dni_api_url", "")
    if not url:
        return {"ok": False, "error": "La consulta automática de DNI no está configurada. Escribe el nombre a mano."}
    peticion = urllib.request.Request(
        url + ("&" if "?" in url else "?") + urlencode({"numero": numero}),
        headers={"Accept": "application/json", "Authorization": "Bearer " + empresa.get("dni_api_token", "")})
    try:
        with urllib.request.urlopen(peticion, timeout=8) as r:
            datos = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, ValueError, OSError):
        return {"ok": False, "error": "No se pudo consultar el DNI. Escribe el nombre a mano."}
    if not isinstance(datos, dict):
        return {"ok": False, "error": "No se encontró ese DNI. Escribe el nombre a mano."}
    partes = [datos.get("nombres", ""),
              datos.get("apellidoPaterno") or datos.get("apellido_paterno", ""),
              datos.get("apellidoMaterno") or datos.get("apellido_materno", "")]
    nombre = " ".join(str(x).strip() for x in partes if x and str(x).strip())
    if not nombre:
        return {"ok": False, "error": "No se encontró ese DNI. Escribe el nombre a mano."}
    return {"ok": True, "nombre": nombre}

def registrar_cliente(datos):
    nombre = str(datos.get("nombre", "")).strip()
    correo = str(datos.get("correo", "")).strip().lower()
    clave = str(datos.get("contrasena", ""))
    if not 2 <= len(nombre) <= 80:
        return {"ok": False, "error": "Escribe tu nombre completo (2 a 80 caracteres)."}
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", correo) or len(correo) > 120:
        return {"ok": False, "error": "Correo electrónico no válido."}
    if len(clave) < 8:
        return {"ok": False, "error": "La contraseña debe tener al menos 8 caracteres."}
    conn = conectar()
    try:
        if conn.execute("SELECT 1 FROM clientes WHERE correo=?", (correo,)).fetchone():
            return {"ok": False, "error": "Ya existe una cuenta con ese correo. Inicia sesión."}
        sal, clave_hash = hash_clave(clave)
        conn.execute("INSERT INTO clientes (nombre, correo, sal, clave_hash, creado) VALUES (?,?,?,?,?)",
                     (nombre, correo, sal, clave_hash, datetime.now().isoformat(timespec="seconds")))
        conn.commit()
    finally:
        conn.close()
    return {"ok": True, "mensaje": "Cuenta creada. Ahora puedes iniciar sesión con tu correo y contraseña.", "correo": correo}

def iniciar_sesion_cliente(datos):
    correo = str(datos.get("correo", "")).strip().lower()
    clave = str(datos.get("contrasena", ""))
    conn = conectar()
    cuenta = conn.execute("SELECT id, nombre, correo, sal, clave_hash, activo FROM clientes WHERE correo=?",
                          (correo,)).fetchone()
    conn.close()
    if not cuenta or not verificar_clave(clave, cuenta["sal"], cuenta["clave_hash"]):
        return None, {"ok": False, "error": "Correo o contraseña incorrectos."}, 401
    if not cuenta["activo"]:
        return None, {"ok": False, "error": "Tu cuenta está desactivada. Escríbenos para ayudarte."}, 403
    token = secrets.token_urlsafe(32)
    CLIENTE_SESIONES[token] = {"id": cuenta["id"], "nombre": cuenta["nombre"], "correo": cuenta["correo"],
                               "expira": datetime.now() + timedelta(hours=SESSION_HOURS)}
    return token, {"ok": True, "nombre": cuenta["nombre"]}, 200

def reservas_del_cliente(correo):
    conn = conectar()
    filas = conn.execute("""SELECT r.codigo, r.fecha, r.asiento, r.total, r.estado, r.metodo_pago,
                                   ru.origen, ru.destino, ru.horario
                            FROM reservas r JOIN rutas ru ON ru.id = r.ruta_id
                            WHERE r.cliente_correo = ? ORDER BY r.fecha DESC, r.id DESC""", (correo,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]

class ServidorHilos(ThreadingHTTPServer):
    """Un hilo por conexión. La cola de espera por defecto es de 5: con muchos usuarios a la vez
    las conexiones se cortaban o esperaban. Se sube a 1024 (el sistema operativo permite más)."""
    request_queue_size = 1024
    daemon_threads = True

class Servidor(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def _json(self, data, codigo=200):
        cuerpo = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def _token_sesion(self):
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get("llampayec_session")
        token = morsel.value if morsel else ""
        expira = SESIONES.get(token)
        if expira and expira > datetime.now():
            return token
        if token:
            SESIONES.pop(token, None)
        return None

    def _requiere_login(self):
        if self._token_sesion():
            return True
        self._json({"ok": False, "error": "Inicia sesión para acceder al panel administrativo."}, 401)
        return False

    def _html(self, cuerpo, codigo=200):
        datos = cuerpo.encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def _control_acceso(self, metodo, ruta):
        roles = roles_para(metodo, ruta)
        if roles is None:
            return True
        token = self._token_sesion()
        if not token:
            if ruta.startswith("/api/"):
                self._json({"ok": False, "error": "Inicia sesión para acceder."}, 401)
            else:
                self.send_response(302); self.send_header("Location", "/login.html"); self.end_headers()
            return False
        if SESION_ROL.get(token) not in roles:
            if ruta.startswith("/api/"):
                self._json({"ok": False, "error": "Acceso Denegado"}, 403)
            else:
                self._html(PAGINA_ACCESO_DENEGADO, 403)
            return False
        return True

    def _cliente_actual(self):
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get(CLIENTE_COOKIE)
        sesion = CLIENTE_SESIONES.get(morsel.value) if morsel else None
        if sesion and sesion["expira"] > datetime.now():
            return sesion
        if morsel:
            CLIENTE_SESIONES.pop(morsel.value, None)
        return None

    def do_GET(self):
        try:
            return self._do_GET()
        except Exception as e:
            self._json({"ok": False, "error": "El sistema está ocupado. Intenta de nuevo en unos segundos."}, 503)
            print("Error en GET:", e)

    def _do_GET(self):
        url = urlparse(self.path)
        ruta = url.path
        params = parse_qs(url.query)
        if not self._control_acceso("GET", ruta): return

        if ruta == "/login.html":
            self.path = "/login.html"
            return super().do_GET()
        if ruta == "/api/sesion":
            token = self._token_sesion()
            return self._json({"autenticado": bool(token), "rol": SESION_ROL.get(token), "usuario": USUARIOS_SESION.get(token)})
        if ruta == "/api/contacto":
            return self._json(api_contacto())
        if ruta == "/api/rutas":
            return self._json(api_rutas())
        if ruta == "/api/asientos":
            try:
                ruta_id = int(params.get("ruta_id", ["0"])[0])
            except ValueError:
                return self._json({"error": "ruta_id invalido"}, 400)
            return self._json(api_asientos(ruta_id, params.get("fecha", [None])[0]))
        if ruta == "/api/admin/resumen":
            if not self._requiere_login(): return
            return self._json(resumen_ventas())
        if ruta == "/api/admin/reservas":
            if not self._requiere_login(): return
            fecha = params.get("fecha", [datetime.now().strftime("%Y-%m-%d")])[0]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha):
                return self._json({"error": "Fecha inválida"}, 400)
            try:
                ruta_id = int(params.get("ruta_id", ["0"])[0] or 0)
            except ValueError:
                return self._json({"error": "ruta_id invalido"}, 400)
            estado = params.get("estado", ["TODAS"])[0]
            return self._json(listar_reservas_admin(fecha, ruta_id, estado))
        if ruta == "/api/cliente/sesion":
            c = self._cliente_actual()
            return self._json({"autenticado": bool(c), "nombre": c["nombre"] if c else None,
                               "correo": c["correo"] if c else None})
        if ruta == "/api/cliente/reservas":
            c = self._cliente_actual()
            if not c:
                return self._json({"ok": False, "error": "Inicia sesión para ver tus reservas."}, 401)
            return self._json(reservas_del_cliente(c["correo"]))
        if ruta == "/api/admin/usuarios":
            return self._json(listar_usuarios())
        if ruta == "/api/admin/empresa":
            empresa = leer_empresa()
            real = leer_empresa()
            empresa["ruc_api_token"] = ""
            empresa["dni_api_token"] = ""
            empresa["token_configurado"] = bool(real.get("ruc_api_token"))
            empresa["token_dni_configurado"] = bool(real.get("dni_api_token"))
            return self._json(empresa)
        if ruta == "/api/caja/empresa":
            empresa = leer_empresa()
            return self._json({k: empresa[k] for k in ("ruc", "razon_social", "direccion", "telefono", "igv_tasa")}
                              | {"ruc_consulta": bool(empresa.get("ruc_api_url")),
                                 "dni_consulta": bool(empresa.get("dni_api_url"))})
        if ruta == "/api/caja/dni":
            return self._json(consultar_dni(params.get("numero", [""])[0].strip()))
        if ruta == "/api/caja/ruc":
            return self._json(consultar_ruc(params.get("numero", [""])[0].strip()))
        if ruta == "/api/caja/permiso-cierre":
            if not self._requiere_login(): return
            rol = SESION_ROL.get(self._token_sesion())
            return self._json({"permitido": rol == "ADMIN" or leer_permiso_cierre()})
        if ruta == "/api/admin/permiso-cierre":
            if not self._requiere_login(): return
            return self._json({"permitido": leer_permiso_cierre()})
        if ruta == "/api/admin/cierre":
            if not self._requiere_login(): return
            if SESION_ROL.get(self._token_sesion()) == "CAJERO" and not leer_permiso_cierre():
                return self._json({"ok": False, "error": "Acceso Denegado"}, 403)
            fecha = params.get("fecha", [datetime.now().strftime("%Y-%m-%d")])[0]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha):
                return self._json({"error": "Fecha inválida"}, 400)
            return self._json(cierre_caja(fecha))
        if ruta == "/api/admin/auditoria":
            if not self._requiere_login(): return
            return self._json(listar_auditoria())
        if ruta == "/caja.html":
            if not self._token_sesion():
                self.send_response(302); self.send_header("Location", "/login.html"); self.end_headers(); return
            self.path = "/caja.html"
        if ruta == "/api/reservas":
            if not self._requiere_login(): return
            return self._json(api_reservas())
        if ruta == "/api/reporte/pdf":
            if not self._requiere_login(): return
            try:
                fecha = params.get("fecha", [None])[0]
                data = crear_pdf_reporte(fecha)
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Disposition", 'attachment; filename="reporte_autobus.pdf"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); return
            except Exception as e:
                return self._json({"error": str(e)}, 500)
        if ruta == "/api/reporte/xlsx":
            if not self._requiere_login(): return
            try:
                fecha = params.get("fecha", [None])[0]
                data = crear_excel_reporte(fecha)
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", 'attachment; filename="reporte_pasajeros.xlsx"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); return
            except Exception as e:
                return self._json({"error": str(e)}, 500)
        if ruta == "/admin.html":
            if not self._token_sesion():
                self.send_response(302); self.send_header("Location", "/login.html"); self.end_headers(); return
            self.path = "/admin.html"
        if ruta in ("/", "/index.html", "/cuenta.html"):
            self.send_response(302); self.send_header("Location", "/login.html"); self.end_headers(); return
        return super().do_GET()

    def do_POST(self):
        try:
            return self._do_POST()
        except Exception as e:
            self._json({"ok": False, "error": "El sistema está ocupado. Intenta de nuevo en unos segundos."}, 503)
            print("Error en POST:", e)

    def _do_POST(self):
        url = urlparse(self.path)
        if not self._control_acceso("POST", url.path): return
        if url.path == "/api/login":
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                usuario = str(datos.get("usuario", "")).strip()
                clave = str(datos.get("contrasena", ""))
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos inválidos."}, 400)
            conn = conectar()
            cuenta = conn.execute("SELECT usuario, sal, clave_hash, rol, activo, nombre FROM usuarios "
                                  "WHERE usuario = ? OR correo = ?", (usuario, usuario.lower())).fetchone()
            if not cuenta or not verificar_clave(clave, cuenta["sal"], cuenta["clave_hash"]):
                conn.close()
                # No es del personal: se intenta como cuenta de cliente (mismo formulario).
                token_cli, resultado_cli, codigo_cli = iniciar_sesion_cliente({"correo": usuario, "contrasena": clave})
                if token_cli:
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Set-Cookie", f"{CLIENTE_COOKIE}={token_cli}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_HOURS*3600}")
                    self.end_headers()
                    self.wfile.write(json.dumps({"ok": True, "tipo": "cliente", "destino": "/login.html",
                                                 "nombre": resultado_cli["nombre"]}).encode("utf-8"))
                    return
                if codigo_cli == 403:
                    return self._json(resultado_cli, 403)
                return self._json({"ok": False, "error": "Usuario o contraseña incorrectos."}, 401)
            if not cuenta["activo"]:
                conn.close()
                return self._json({"ok": False, "error": "Tu cuenta está desactivada. Contacta al administrador."}, 403)
            registrar_auditoria(conn, cuenta["usuario"], "INGRESO", cuenta["rol"])
            conn.commit()
            conn.close()
            token = secrets.token_urlsafe(32)
            SESIONES[token] = datetime.now() + timedelta(hours=SESSION_HOURS)
            USUARIOS_SESION[token] = cuenta["usuario"]
            SESION_ROL[token] = cuenta["rol"]
            destino = "/caja.html" if cuenta["rol"] == "CAJERO" else "/admin.html"
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Set-Cookie", f"llampayec_session={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_HOURS*3600}")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": True, "rol": cuenta["rol"], "destino": destino,
                                         "nombre": cuenta["nombre"] or cuenta["usuario"]}).encode("utf-8"))
            return
        if url.path == "/api/logout":
            token = self._token_sesion()
            if token:
                SESIONES.pop(token, None)
                USUARIOS_SESION.pop(token, None)
                SESION_ROL.pop(token, None)
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Set-Cookie", "llampayec_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0")
            self.end_headers(); self.wfile.write(b'{"ok":true}'); return
        if url.path == "/api/admin/permiso-cierre":
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            actor = USUARIOS_SESION.get(self._token_sesion(), "admin")
            return self._json(guardar_permiso_cierre(bool(datos.get("permitido")), actor))
        if url.path in ("/api/admin/usuario", "/api/admin/empresa"):
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            actor = USUARIOS_SESION.get(self._token_sesion(), "admin")
            if url.path == "/api/admin/usuario":
                resultado = accion_usuario(datos, actor)
            else:
                resultado = guardar_empresa(datos, actor)
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path == "/api/cliente/registro":
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            resultado = registrar_cliente(datos)
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path == "/api/cliente/login":
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            token, resultado, codigo = iniciar_sesion_cliente(datos)
            if not token:
                return self._json(resultado, codigo)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Set-Cookie", f"{CLIENTE_COOKIE}={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_HOURS*3600}")
            self.end_headers()
            self.wfile.write(json.dumps(resultado).encode("utf-8"))
            return
        if url.path == "/api/cliente/logout":
            c = self._cliente_actual()
            cookie = SimpleCookie(self.headers.get("Cookie", ""))
            morsel = cookie.get(CLIENTE_COOKIE)
            if morsel: CLIENTE_SESIONES.pop(morsel.value, None)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Set-Cookie", f"{CLIENTE_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0")
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
            return
        if url.path == "/api/cliente/reservar":
            c = self._cliente_actual()
            if not c:
                return self._json({"ok": False, "error": "Inicia sesión para comprar tu pasaje."}, 401)
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos inválidos"}, 400)
            # En línea solo se cobra con medios electrónicos; el efectivo es únicamente en caja.
            if str(datos.get("metodo_pago", "")) not in METODOS_WEB:
                return self._json({"ok": False, "error": "Elige un medio de pago: Tarjeta, Yape, Plin o PayPal."}, 400)
            resultado = api_reservar(datos, cliente_correo=c["correo"])
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path == "/api/admin/precios-piso":
            if not self._requiere_login(): return
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            usuario = USUARIOS_SESION.get(self._token_sesion(), "caja")
            resultado = guardar_precios_piso(datos, usuario)
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path == "/api/caja/venta":
            if not self._requiere_login(): return
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            resultado = api_reservar(datos, caja=datos)
            if resultado["ok"]:
                usuario = USUARIOS_SESION.get(self._token_sesion(), "admin")
                conn = conectar()
                registrar_auditoria(conn, usuario, "VENTA_CAJA",
                                    f"{resultado['codigo']} · {datos['metodo_pago']} · S/ {resultado['total']:.2f}")
                conn.commit(); conn.close()
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path in ("/api/admin/reserva", "/api/admin/ruta", "/api/admin/mover"):
            if not self._requiere_login(): return
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
                if not isinstance(datos, dict):
                    raise ValueError
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            usuario = USUARIOS_SESION.get(self._token_sesion(), "admin")
            if url.path == "/api/admin/reserva":
                resultado = accion_reserva(datos, usuario)
            elif url.path == "/api/admin/mover":
                resultado = mover_asiento(datos, usuario)
            else:
                resultado = guardar_ruta_admin(datos, usuario)
            return self._json(resultado, 200 if resultado["ok"] else 400)
        if url.path == "/api/contacto":
            if not self._requiere_login(): return
            try:
                largo = int(self.headers.get("Content-Length", 0))
                datos = json.loads(self.rfile.read(largo).decode("utf-8"))
            except (ValueError, json.JSONDecodeError):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            if not isinstance(datos, dict):
                return self._json({"ok": False, "error": "Datos invalidos"}, 400)
            resultado = api_guardar_contacto(datos)
            return self._json(resultado, 200 if resultado["ok"] else 400)
        self._json({"error": "Ruta no encontrada"}, 404)

    def log_message(self, formato, *args):
        pass

if __name__ == "__main__":
    crear_tablas()
    servidor = ServidorHilos(("0.0.0.0", PUERTO), Servidor)
    print("=" * 55)
    print("  LLAMPAYEC - Servidor de reservas en linea")
    print("  Pagina web:   http://localhost:%d" % PUERTO)
    print("  Panel admin:  http://localhost:%d/admin.html" % PUERTO)
    print("  Presiona Ctrl+C para detener")
    print("=" * 55)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
